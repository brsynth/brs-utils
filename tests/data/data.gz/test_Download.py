"""
Created on Jul 14 2020

@author: Joan Hérisson
"""

from unittest import TestCase

from brs_utils import download, extract_gz, download_and_extract_gz
from tempfile import NamedTemporaryFile
from hashlib import sha256
from pathlib import Path
from time import sleep

class Test_Download(TestCase):

    def test_download(self):
        with NamedTemporaryFile() as tempf:
            download('https://github.com/brsynth/rpCache-data/raw/master/cache.tar.gz',
                     tempf.name)
            self.assertEqual(
                sha256(Path(tempf.name).read_bytes()).hexdigest(),
                '1acb965e153a64e96f550ae8fbacf592e56ce7e3d01956e7343cb0e08b34602e'
                            )

    def test_download(self):
        with NamedTemporaryFile() as tempf:
            download('https://github.com/brsynth/rpCache-data/raw/master/cache.tar.gz',
                     tempf.name)
            self.assertEqual(
                sha256(Path(tempf.name).read_bytes()).hexdigest(),
                '1acb965e153a64e96f550ae8fbacf592e56ce7e3d01956e7343cb0e08b34602e'
                            )
